import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table definition (kept from the original)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Scan type enum
export const ScanType = {
  QUICK: "quick",
  FULL: "full",
  OS: "os",
  CUSTOM: "custom",
  NFS_SCAN: "nfs_scan", // Add NFS specific scan
  VULN_SCAN: "vuln_scan", // Scan for vulnerabilities
} as const;

export type ScanTypeValue = typeof ScanType[keyof typeof ScanType];

// Scan status enum
export const ScanStatus = {
  PENDING: "pending",
  RUNNING: "running",
  COMPLETED: "completed",
  FAILED: "failed",
  CANCELLED: "cancelled",
} as const;

export type ScanStatusValue = typeof ScanStatus[keyof typeof ScanStatus];

// Scan table definition
export const scans = pgTable("scans", {
  id: serial("id").primaryKey(),
  target: text("target").notNull(),
  type: text("type").notNull(),
  customFlags: text("custom_flags"),
  status: text("status").notNull().default(ScanStatus.PENDING),
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  duration: integer("duration"),
  output: text("output"),
  xmlOutput: text("xml_output"),
  error: text("error"),
  options: text("options"),
});

// Scan request schema
export const scanRequestSchema = z.object({
  target: z.string().min(1, "Target is required"),
  type: z.enum([ScanType.QUICK, ScanType.FULL, ScanType.OS, ScanType.CUSTOM, ScanType.NFS_SCAN, ScanType.VULN_SCAN]),
  customFlags: z.string().optional(),
  options: z.object({
    verbose: z.boolean().default(false),
    saveResult: z.boolean().default(false),
  }).optional(),
});

// Scan result schemas
export const portSchema = z.object({
  port: z.number(),
  protocol: z.string(),
  service: z.string(),
  state: z.string(),
  version: z.string().optional(),
});

export const hostSchema = z.object({
  ip: z.string(),
  hostname: z.string().optional(),
  status: z.string(),
  mac: z.string().optional(),
  vendor: z.string().optional(),
  os: z.string().optional(),
  osConfidence: z.number().optional(),
  type: z.string().optional(),
  ports: z.array(portSchema).optional(),
});

export const scanResultSchema = z.object({
  id: z.number(),
  target: z.string(),
  type: z.string(),
  status: z.string(),
  startTime: z.string().optional(),
  endTime: z.string().optional(),
  duration: z.number().optional(),
  hostsTotal: z.number().optional(),
  hostsUp: z.number().optional(),
  hosts: z.array(hostSchema).optional(),
  output: z.string().optional(),
  error: z.string().optional(),
});

// Insert and select types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type ScanRequest = z.infer<typeof scanRequestSchema>;
export type Port = z.infer<typeof portSchema>;
export type Host = z.infer<typeof hostSchema>;
export type ScanResult = z.infer<typeof scanResultSchema>;
export type InsertScan = typeof scans.$inferInsert;
export type Scan = typeof scans.$inferSelect;
