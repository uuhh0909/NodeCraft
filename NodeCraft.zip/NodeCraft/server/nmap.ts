import { spawn } from "child_process";
import { ScanRequest, ScanType, Host, Port, ScanResult } from "@shared/schema";
import { promises as fs } from "fs";
import path from "path";
import os from "os";
import { parseStringPromise } from "xml2js";

// Safe command execution with sanitization
function sanitizeInput(input: string): string {
  // Remove any characters that could be used for command injection
  return input.replace(/[;&|`<>$(){}[\]!#]/g, "");
}

export async function checkNmapInstalled(): Promise<boolean> {
  try {
    const process = spawn("nmap", ["--version"]);
    return new Promise<boolean>((resolve) => {
      process.on("close", (code) => {
        resolve(code === 0);
      });
      
      // Timeout after 2 seconds
      setTimeout(() => resolve(false), 2000);
    });
  } catch (error) {
    return false;
  }
}

export async function runNmapScan(scan: ScanRequest, scanId: number): Promise<{
  success: boolean;
  output?: string;
  xmlOutput?: string;
  error?: string;
}> {
  try {
    // Create temporary file for XML output
    const tmpDir = os.tmpdir();
    const xmlOutputFile = path.join(tmpDir, `scan_${scanId}_${Date.now()}.xml`);
    
    // Sanitize inputs
    const target = sanitizeInput(scan.target);
    
    // Prepare Nmap command based on scan type
    const args: string[] = [];
    
    // Always output XML for structured data
    args.push("-oX", xmlOutputFile);
    
    if (scan.options?.verbose) {
      args.push("-v");
    }
    
    switch(scan.type) {
      case ScanType.QUICK:
        args.push("-sT", "-F", "-T4");  // Using -sT (TCP connect scan) instead of -sS which requires root
        break;
      case ScanType.FULL:
        args.push("-sT", "-p-", "-T4"); // Using -sT instead of -sS, removed -A as it may require root
        break;
      case ScanType.OS:
        args.push("-sT", "-T4");  // Simplified, as -O requires root privileges
        break;
      case ScanType.NFS_SCAN:
        // Specific scan for NFS services and potential vulnerabilities
        args.push("-sT", "-p", "111,2049,1110,4045", "--script=nfs-ls,nfs-showmount,nfs-statfs");
        break;
      case ScanType.VULN_SCAN:
        // Scan for common vulnerabilities
        args.push("-sT", "-sV", "--script=vuln");
        break;
      case ScanType.CUSTOM:
        if (scan.customFlags) {
          // Split by space but keep quoted parts together
          const customArgs = scan.customFlags.match(/(?:[^\s"]+|"[^"]*")+/g);
          if (customArgs) {
            // Sanitize each custom arg
            customArgs.forEach(arg => args.push(sanitizeInput(arg)));
          }
        }
        break;
    }
    
    // Add target as the last argument
    args.push(target);
    
    console.log(`Running nmap command: nmap ${args.join(' ')}`);
    
    // Spawn Nmap process
    const nmapProcess = spawn("nmap", args);
    
    let stdoutData = "";
    let stderrData = "";
    
    nmapProcess.stdout.on("data", (data) => {
      stdoutData += data.toString();
    });
    
    nmapProcess.stderr.on("data", (data) => {
      stderrData += data.toString();
    });
    
    return new Promise((resolve, reject) => {
      nmapProcess.on("close", async (code) => {
        if (code === 0) {
          try {
            // Read XML output file
            const xmlData = await fs.readFile(xmlOutputFile, "utf8");
            
            // Clean up temporary file
            await fs.unlink(xmlOutputFile).catch(() => {});
            
            resolve({
              success: true,
              output: stdoutData,
              xmlOutput: xmlData,
            });
          } catch (err) {
            resolve({
              success: false,
              output: stdoutData,
              error: `Failed to read XML output: ${err}`,
            });
          }
        } else {
          resolve({
            success: false,
            output: stdoutData,
            error: stderrData || `Nmap process exited with code ${code}`,
          });
        }
      });
      
      nmapProcess.on("error", (err) => {
        resolve({
          success: false,
          error: `Failed to start Nmap: ${err.message}`,
        });
      });
    });
  } catch (error) {
    return {
      success: false,
      error: `Exception running Nmap: ${error}`,
    };
  }
}

export async function parseNmapXML(xmlData: string): Promise<{
  hosts: Host[];
  hostsTotal: number;
  hostsUp: number;
}> {
  try {
    const result = await parseStringPromise(xmlData, { explicitArray: false });
    const nmapRun = result.nmaprun;
    
    const hosts: Host[] = [];
    const hostsTotal = parseInt(nmapRun.runstats.hosts.$.total, 10);
    const hostsUp = parseInt(nmapRun.runstats.hosts.$.up, 10);
    
    // Ensure hosts is always an array
    const hostEntries = Array.isArray(nmapRun.host) ? nmapRun.host : (nmapRun.host ? [nmapRun.host] : []);
    
    for (const hostEntry of hostEntries) {
      const host: Host = {
        ip: "",
        status: "",
      };
      
      // Get IP address
      if (hostEntry.address) {
        if (Array.isArray(hostEntry.address)) {
          const ipv4 = hostEntry.address.find(addr => addr.$.addrtype === 'ipv4');
          if (ipv4) {
            host.ip = ipv4.$.addr;
          }
          
          const mac = hostEntry.address.find(addr => addr.$.addrtype === 'mac');
          if (mac) {
            host.mac = mac.$.addr;
            host.vendor = mac.$.vendor;
          }
        } else {
          host.ip = hostEntry.address.$.addr;
        }
      }
      
      // Get hostname
      if (hostEntry.hostnames && hostEntry.hostnames.hostname) {
        if (Array.isArray(hostEntry.hostnames.hostname)) {
          host.hostname = hostEntry.hostnames.hostname[0].$.name;
        } else {
          host.hostname = hostEntry.hostnames.hostname.$.name;
        }
      }
      
      // Get status
      if (hostEntry.status) {
        host.status = hostEntry.status.$.state;
      }
      
      // Get OS info
      if (hostEntry.os && hostEntry.os.osmatch) {
        if (Array.isArray(hostEntry.os.osmatch)) {
          const bestMatch = hostEntry.os.osmatch[0];
          host.os = bestMatch.$.name;
          host.osConfidence = parseInt(bestMatch.$.accuracy, 10);
        } else {
          host.os = hostEntry.os.osmatch.$.name;
          host.osConfidence = parseInt(hostEntry.os.osmatch.$.accuracy, 10);
        }
      }
      
      // Get ports
      if (hostEntry.ports && hostEntry.ports.port) {
        const ports: Port[] = [];
        const portEntries = Array.isArray(hostEntry.ports.port) ? hostEntry.ports.port : [hostEntry.ports.port];
        
        for (const portEntry of portEntries) {
          ports.push({
            port: parseInt(portEntry.$.portid, 10),
            protocol: portEntry.$.protocol,
            service: portEntry.service ? portEntry.service.$.name : "unknown",
            state: portEntry.state.$.state,
            version: portEntry.service ? portEntry.service.$.product : undefined,
          });
        }
        
        host.ports = ports;
      }
      
      hosts.push(host);
    }
    
    return {
      hosts,
      hostsTotal,
      hostsUp,
    };
  } catch (error) {
    console.error("Error parsing Nmap XML:", error);
    return {
      hosts: [],
      hostsTotal: 0,
      hostsUp: 0,
    };
  }
}
