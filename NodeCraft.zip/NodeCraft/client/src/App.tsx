import { Switch, Route } from "wouter";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import ScanResults from "@/pages/ScanResults";
import Header from "@/components/Header";
import Console from "@/pages/Console";
import ExploitLab from "@/pages/ExploitLab";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/scans/:id" component={ScanResults} />
      <Route path="/console" component={Console} />
      <Route path="/exploit-lab" component={ExploitLab} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <TooltipProvider>
      <div className="min-h-screen flex flex-col bg-gray-100">
        <Header />
        <Router />
      </div>
    </TooltipProvider>
  );
}

export default App;
