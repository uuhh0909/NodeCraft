import { useState } from "react";
import ScanForm from "@/components/ScanForm";
import ScanHistory from "@/components/ScanHistory";
import ResultsPanel from "@/components/ResultsPanel";
import { ScanStatus } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

export default function Home() {
  const [currentScanId, setCurrentScanId] = useState<number | null>(null);
  const [scanView, setScanView] = useState<"idle" | "loading" | "results" | "error">("idle");
  
  // Fetch server health status
  const { data: healthData } = useQuery({ 
    queryKey: ['/api/health'],
    refetchInterval: 60000, // Check every minute
  });
  
  const nmapInstalled = healthData?.nmap === "installed";
  const serverOnline = healthData?.status === "ok";

  return (
    <main className="container mx-auto px-4 py-6 flex-grow">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Left column with scan controls */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-5">
            <h2 className="text-lg font-medium text-primary mb-4 flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-5 h-5 mr-2"
              >
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.3-4.3" />
              </svg>
              Scan Controls
            </h2>
            
            <ScanForm 
              onScanStart={(scanId) => {
                setCurrentScanId(scanId);
                setScanView("loading");
              }} 
              nmapInstalled={nmapInstalled}
            />
            
            <ScanHistory 
              onSelectScan={(scanId) => {
                setCurrentScanId(scanId);
                setScanView("results");
              }}
            />
          </div>
        </div>
        
        {/* Right column with results */}
        <div className="lg:col-span-3">
          <ResultsPanel 
            scanId={currentScanId}
            view={scanView}
            onViewChange={(view) => setScanView(view)}
            onNewScan={() => {
              setCurrentScanId(null);
              setScanView("idle");
            }}
          />
        </div>
      </div>
    </main>
  );
}
