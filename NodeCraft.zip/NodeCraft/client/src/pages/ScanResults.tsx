import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import ResultsPanel from "@/components/ResultsPanel";
import Header from "@/components/Header";

export default function ScanResults() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  
  // Convert id to number
  const scanId = parseInt(id);
  
  // If id is not a valid number, redirect to home
  if (isNaN(scanId)) {
    navigate("/");
    return null;
  }
  
  // Query scan details
  const { data: scan, isLoading, isError } = useQuery({
    queryKey: [`/api/scans/${scanId}`],
  });
  
  let view: "idle" | "loading" | "results" | "error" = "idle";
  
  if (isLoading) {
    view = "loading";
  } else if (isError) {
    view = "error";
  } else if (scan) {
    view = "results";
  }
  
  return (
    <main className="container mx-auto px-4 py-6 flex-grow">
      <div className="mb-4">
        <button 
          onClick={() => navigate("/")}
          className="flex items-center text-primary hover:text-primary-light"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-4 h-4 mr-1"
          >
            <path d="m15 18-6-6 6-6" />
          </svg>
          Back to Scanner
        </button>
      </div>
      
      <div className="grid grid-cols-1">
        <ResultsPanel 
          scanId={scanId}
          view={view}
          onNewScan={() => navigate("/")}
        />
      </div>
    </main>
  );
}
