import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

type CommandHistoryItem = {
  command: string;
  output: string;
  isError: boolean;
  timestamp: Date;
};

type WebSocketMessage = {
  type: string;
  command?: string;
  output?: string;
  error?: string | null;
  message?: string;
  timestamp: string;
};

export default function Console() {
  const { toast } = useToast();
  const [command, setCommand] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [commandHistory, setCommandHistory] = useState<CommandHistoryItem[]>([
    {
      command: "help",
      output: "Available commands:\n- nmap [options] <target>\n- burpsuite\n- metasploit\n- hydra [options] <target>\n- sqlmap [options] <target>\n- john [options] <hashfile>\n- wireshark\n- aircrack-ng [options] <capture file>\n\nFor tool-specific help, type '<tool_name> --help'",
      isError: false,
      timestamp: new Date()
    }
  ]);
  const [selectedTool, setSelectedTool] = useState<string>("console");
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  
  const outputEndRef = useRef<HTMLDivElement>(null);
  
  // Setup WebSocket connection
  useEffect(() => {
    // Create WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log("WebSocket connected");
      setIsConnected(true);
      toast({
        title: "Console Connected",
        description: "Successfully connected to command console"
      });
    };
    
    ws.onmessage = (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);
        
        if (message.type === 'command_result') {
          setCommandHistory(prev => {
            // Try to find the command in history that's being processed
            const index = prev.findIndex(item => 
              item.command === message.command && 
              item.output === "Processing command..."
            );
            
            if (index !== -1) {
              const updated = [...prev];
              updated[index] = {
                command: message.command!,
                output: message.output || "",
                isError: Boolean(message.error),
                timestamp: new Date()
              };
              return updated;
            }
            
            // If not found, add as new item
            return [...prev, {
              command: message.command || "",
              output: message.output || "",
              isError: Boolean(message.error),
              timestamp: new Date()
            }];
          });
          
          setIsProcessing(false);
        } else if (message.type === 'system') {
          // Add system messages to history
          setCommandHistory(prev => [...prev, {
            command: "SYSTEM",
            output: message.message || "",
            isError: false,
            timestamp: new Date()
          }]);
        } else if (message.type === 'error') {
          // Handle error messages
          setCommandHistory(prev => {
            const lastIndex = prev.length - 1;
            if (lastIndex >= 0 && prev[lastIndex].output === "Processing command...") {
              const updated = [...prev];
              updated[lastIndex] = {
                ...updated[lastIndex],
                output: message.message || "Unknown error occurred",
                isError: true
              };
              return updated;
            }
            return [...prev, {
              command: "ERROR",
              output: message.message || "Unknown error occurred",
              isError: true,
              timestamp: new Date()
            }];
          });
          
          setIsProcessing(false);
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    };
    
    ws.onclose = () => {
      console.log("WebSocket disconnected");
      setIsConnected(false);
      
      // Add disconnection message to history
      setCommandHistory(prev => [...prev, {
        command: "SYSTEM",
        output: "Console disconnected. Please refresh the page to reconnect.",
        isError: true,
        timestamp: new Date()
      }]);
      
      // Try to reconnect after a delay
      setTimeout(() => {
        toast({
          title: "Connection Lost",
          description: "Reconnecting to console...",
          variant: "destructive"
        });
      }, 1000);
    };
    
    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      toast({
        title: "Connection Error",
        description: "Failed to connect to the console server",
        variant: "destructive"
      });
    };
    
    setSocket(ws);
    
    // Clean up on unmount
    return () => {
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
        ws.close();
      }
    };
  }, [toast]);
  
  // Auto-scroll to bottom of console output
  useEffect(() => {
    if (outputEndRef.current) {
      outputEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [commandHistory]);
  
  // Execute command
  const executeCommand = async () => {
    if (!command.trim() || !isConnected || isProcessing) return;
    
    const trimmedCommand = command.trim();
    
    // Special case for client-side clear command
    if (trimmedCommand === "clear" || trimmedCommand === "cls") {
      setCommandHistory([]);
      setCommand("");
      return;
    }
    
    setCommandHistory(prev => [...prev, {
      command: trimmedCommand,
      output: "Processing command...",
      isError: false,
      timestamp: new Date()
    }]);
    
    setIsProcessing(true);
    
    // If we have a websocket connection, send command through it
    if (socket && socket.readyState === WebSocket.OPEN) {
      try {
        socket.send(JSON.stringify({
          type: 'command',
          command: trimmedCommand
        }));
        setCommand("");
      } catch (error) {
        console.error("Error sending command:", error);
        setCommandHistory(prev => {
          const updated = [...prev];
          updated[updated.length - 1] = {
            command: trimmedCommand,
            output: `Error sending command: ${error}`,
            isError: true,
            timestamp: new Date()
          };
          return updated;
        });
        
        setIsProcessing(false);
        setCommand("");
      }
    } else {
      // Fallback to simulated responses if websocket isn't available
      try {
        // Simulate execution with sample responses
        let output = "";
        let isError = false;
        
        // Handle specific commands
        if (trimmedCommand.startsWith("nmap")) {
          output = simulateNmapOutput(trimmedCommand);
        } else if (trimmedCommand.startsWith("burpsuite")) {
          output = "Starting Burp Suite...\nBurp Suite Professional v2023.1.2\nJava version: 11.0.16\nInitializing graphical interface...";
        } else if (trimmedCommand.startsWith("metasploit")) {
          output = simulateMetasploitOutput(trimmedCommand);
        } else if (trimmedCommand.startsWith("hydra")) {
          output = simulateHydraOutput(trimmedCommand);
        } else if (trimmedCommand.startsWith("sqlmap")) {
          output = simulateSqlmapOutput(trimmedCommand);
        } else if (trimmedCommand === "help") {
          output = "Available commands:\n- nmap [options] <target>\n- burpsuite\n- metasploit\n- hydra [options] <target>\n- sqlmap [options] <target>\n- john [options] <hashfile>\n- wireshark\n- aircrack-ng [options] <capture file>\n\nFor tool-specific help, type '<tool_name> --help'";
        } else {
          output = `Command not found: ${trimmedCommand}\nType 'help' for available commands.`;
          isError = true;
        }
        
        // Add a slight delay to simulate processing
        setTimeout(() => {
          setCommandHistory(prev => {
            const updated = [...prev];
            updated[updated.length - 1] = {
              command: trimmedCommand,
              output,
              isError,
              timestamp: new Date()
            };
            return updated;
          });
          
          setIsProcessing(false);
          setCommand("");
        }, 1000);
        
      } catch (error) {
        setCommandHistory(prev => {
          const updated = [...prev];
          updated[updated.length - 1] = {
            command: trimmedCommand,
            output: `Error executing command: ${error}`,
            isError: true,
            timestamp: new Date()
          };
          return updated;
        });
        
        setIsProcessing(false);
        setCommand("");
      }
    }
  };
  
  // Handle enter key press
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !isProcessing) {
      executeCommand();
    }
  };
  
  // Simulate output for demo purposes
  const simulateNmapOutput = (cmd: string) => {
    if (cmd.includes("--help") || cmd === "nmap -h") {
      return `Nmap 7.93 Usage: nmap [Scan Type] [Options] {target specification}
Scan Types:
  -sS/sT/sA/sW/sM: TCP SYN/Connect/ACK/Window/Maimon scans
  -sU: UDP Scan
  -sN/sF/sX: TCP Null, FIN, and Xmas scans
  --scanflags <flags>: Customize TCP scan flags
  -sI <zombie host[:probeport]>: Idle scan
  -sY/sZ: SCTP INIT/COOKIE-ECHO scans
  -sO: IP protocol scan
  -b <FTP relay host>: FTP bounce scan
Output:
  -oN/-oX/-oS/-oG <file>: Output scan in normal, XML, script kiddie, and Grepable format
  -oA <basename>: Output in the three major formats at once
  -v: Increase verbosity level (use -vv or more for greater effect)
  -d: Increase debugging level (use -dd or more for greater effect)
  --reason: Display the reason a port is in a particular state
  --open: Only show open (or possibly open) ports
  --packet-trace: Show all packets sent and received
  --iflist: Print host interfaces and routes (for debugging)
  --append-output: Append to rather than clobber specified output files
  --resume <filename>: Resume an aborted scan
  --noninteractive: Disable runtime interactions via keyboard
  --stylesheet <path/URL>: XSL stylesheet to transform XML output to HTML
  --webxml: Reference stylesheet from Nmap.Org for more portable XML
  --no-stylesheet: Prevent associating of XSL stylesheet w/XML output`;
    }
    
    return `Starting Nmap 7.93 ( https://nmap.org ) at ${new Date().toLocaleString()}
Nmap scan report for target.example.com (10.10.10.10)
Host is up (0.015s latency).
Not shown: 995 closed ports
PORT     STATE SERVICE
21/tcp   open  ftp
22/tcp   open  ssh
80/tcp   open  http
443/tcp  open  https
3306/tcp open  mysql

Nmap done: 1 IP address (1 host up) scanned in 5.32 seconds`;
  };
  
  const simulateMetasploitOutput = (cmd: string) => {
    return `
    Metasploit Framework v6.2.27-dev

       +-------------------------------------------------------+
       |  METASPLOIT by Rapid7                                 |
       +---------------------------+---------------------------+
       |      __________________   |                           |
       |  ==c(______(o(______(_()  | |""""""""""""|======[***  |
       |             )=\\           | |  EXPLOIT              |
       |            // \\\\          | |___________________|   |
       |           //   \\\\         | |==[msf >]============|  |
       |          //     \\\\        | |______________________| |
       |         // RECON \\\\       | |_______________________|
       |        //         \\\\      |                          |
       +---------------------------+---------------------------+
       |      o O o                |        \'\/\',|\'\'\'\'\'\'|\\
       |              o O          |         )====TTTT|====
       |                 o         |        /      |  |
       +-------------------------------------------------------+

    Using configuration from: /opt/metasploit-framework/config/config
    msf6 >
    `;
  };
  
  const simulateHydraOutput = (cmd: string) => {
    return `Hydra v9.3 (c) 2022 by van Hauser/THC & David Maciejak - for legal purposes only

Hydra (https://github.com/vanhauser-thc/thc-hydra) starting
[DATA] 16 tasks, 1 server, 80 login tries (l:8/p:10), ~5 tries per task
[DATA] attacking http-post-form://example.com:80/login.php
[80][http-post-form] host: example.com   login: admin   password: admin123
[80][http-post-form] host: example.com   login: user   password: password123
[STATUS] attack finished for example.com (waiting for children to complete tests)
1 of 1 target successfully completed, 2 valid passwords found
Hydra (https://github.com/vanhauser-thc/thc-hydra) finished.`;
  };
  
  const simulateSqlmapOutput = (cmd: string) => {
    return `
        ___ ___[.]_____ ___ ___  {1.6.10#stable}
       |_ -| . [)]     | .'| . |
       |___|_  [,]_|_|_|__,|  _|
             |_|V...       |_|   https://sqlmap.org

[!] legal disclaimer: Usage of sqlmap for attacking targets without prior mutual consent is illegal. It is the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program

[*] starting @ 14:21:25 /2023-04-15/

[14:21:25] [INFO] testing connection to the target URL
[14:21:26] [INFO] checking if the target is protected by some kind of WAF/IPS
[14:21:26] [INFO] testing if the target URL content is stable
[14:21:27] [INFO] target URL content is stable
[14:21:27] [INFO] testing if GET parameter 'id' is dynamic
[14:21:27] [INFO] GET parameter 'id' appears to be dynamic
[14:21:28] [INFO] heuristic (basic) test shows that GET parameter 'id' might be injectable (possible DBMS: 'MySQL')
[14:21:29] [INFO] testing for SQL injection on GET parameter 'id'
[14:21:29] [INFO] testing 'AND boolean-based blind - WHERE or HAVING clause'
[14:21:30] [INFO] GET parameter 'id' appears to be 'AND boolean-based blind - WHERE or HAVING clause' injectable 
[14:21:32] [INFO] testing 'MySQL >= 5.0 AND error-based - WHERE, HAVING, ORDER BY or GROUP BY clause (FLOOR)'
[14:21:33] [INFO] GET parameter 'id' is 'MySQL >= 5.0 AND error-based - WHERE, HAVING, ORDER BY or GROUP BY clause (FLOOR)' injectable 
[14:21:33] [INFO] testing 'MySQL inline queries'
[14:21:33] [INFO] testing 'MySQL > 5.0.11 stacked queries (comment)'
[14:21:34] [INFO] testing 'MySQL > 5.0.11 stacked queries'
[14:21:34] [INFO] testing 'MySQL > 5.0.11 stacked queries (query SLEEP - comment)'
[14:21:35] [INFO] testing 'MySQL > 5.0.11 stacked queries (query SLEEP)'
[14:21:35] [INFO] testing 'MySQL < 5.0.12 stacked queries (heavy query - comment)'
[14:21:35] [INFO] testing 'MySQL < 5.0.12 stacked queries (heavy query)'
[14:21:36] [INFO] testing 'MySQL >= 5.0.12 AND time-based blind'
[14:21:46] [INFO] GET parameter 'id' appears to be 'MySQL >= 5.0.12 AND time-based blind' injectable 
[14:21:46] [INFO] testing 'Generic UNION query (NULL) - 1 to 20 columns'
[14:21:46] [INFO] automatically extending ranges for UNION query injection technique tests as there is at least one other (potential) technique found
[14:21:47] [INFO] 'ORDER BY' technique appears to be usable. This should reduce the time needed to find the right number of query columns. Automatically extending the range for current UNION query injection technique test
[14:21:48] [INFO] target URL appears to have 3 columns in query
[14:21:49] [INFO] GET parameter 'id' is 'Generic UNION query (NULL) - 1 to 20 columns' injectable
[14:21:49] [INFO] the back-end DBMS is MySQL
[14:21:49] [INFO] fetching database names
available databases [5]:
[*] information_schema
[*] mysql
[*] performance_schema
[*] sys
[*] website

[14:21:50] [INFO] fetched data logged to text files under '/root/.local/share/sqlmap/output/example.com'

[*] ending @ 14:21:50 /2023-04-15/
    `;
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <Card className="bg-gray-900 text-white border-gray-800">
        <CardHeader className="border-b border-gray-800">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-xl font-mono">Ethical Hacking Console</CardTitle>
              <CardDescription className="text-gray-400">
                Execute security tools and commands
              </CardDescription>
            </div>
            <Select
              value={selectedTool}
              onValueChange={setSelectedTool}
            >
              <SelectTrigger className="w-[180px] bg-gray-800 border-gray-700">
                <SelectValue placeholder="Select Tool" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                <SelectItem value="console">Command Console</SelectItem>
                <SelectItem value="metasploit">Metasploit</SelectItem>
                <SelectItem value="nmap">Nmap</SelectItem>
                <SelectItem value="burpsuite">Burp Suite</SelectItem>
                <SelectItem value="sqlmap">SQLMap</SelectItem>
                <SelectItem value="hydra">Hydra</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="bg-black font-mono text-sm p-4 h-[500px] overflow-y-auto">
            {commandHistory.map((item, index) => (
              <div key={index} className="mb-2">
                <div className="flex">
                  <span className="text-green-500 mr-2">$</span>
                  <span className="text-white font-bold">{item.command}</span>
                </div>
                <div className={`ml-4 whitespace-pre-wrap ${item.isError ? 'text-red-400' : 'text-gray-300'}`}>
                  {item.output}
                </div>
              </div>
            ))}
            <div ref={outputEndRef} />
          </div>
        </CardContent>
        <CardFooter className="border-t border-gray-800 p-2">
          <div className="flex w-full items-center space-x-2">
            <Input
              type="text"
              placeholder="Enter command..."
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              onKeyDown={handleKeyDown}
              className="flex-grow bg-gray-800 border-gray-700 text-white"
              disabled={isProcessing}
            />
            <Button 
              onClick={executeCommand}
              disabled={isProcessing || !command.trim()}
              className="bg-green-600 hover:bg-green-700"
            >
              Execute
            </Button>
          </div>
        </CardFooter>
      </Card>
      
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-gray-900 text-white border-gray-800">
          <CardHeader>
            <CardTitle>Common Commands</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="p-2 bg-gray-800 rounded">
                <code className="text-green-400">nmap -sT -p- example.com</code>
                <p className="text-xs text-gray-400 mt-1">Full TCP port scan of a target</p>
              </li>
              <li className="p-2 bg-gray-800 rounded">
                <code className="text-green-400">hydra -l admin -P wordlist.txt target http-post-form</code>
                <p className="text-xs text-gray-400 mt-1">Brute force a web login form</p>
              </li>
              <li className="p-2 bg-gray-800 rounded">
                <code className="text-green-400">sqlmap -u "http://example.com/page?id=1" --dbs</code>
                <p className="text-xs text-gray-400 mt-1">SQL injection test to enumerate databases</p>
              </li>
              <li className="p-2 bg-gray-800 rounded">
                <code className="text-green-400">metasploit</code>
                <p className="text-xs text-gray-400 mt-1">Launch Metasploit Framework console</p>
              </li>
            </ul>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900 text-white border-gray-800">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {commandHistory.slice(-5).reverse().map((item, index) => (
                <div key={index} className="flex items-start p-2 bg-gray-800 rounded">
                  <div className={`w-2 h-2 rounded-full mt-2 mr-2 ${item.isError ? 'bg-red-500' : 'bg-green-500'}`}></div>
                  <div>
                    <p className="text-sm font-medium">{item.command}</p>
                    <p className="text-xs text-gray-400">{item.timestamp.toLocaleTimeString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}