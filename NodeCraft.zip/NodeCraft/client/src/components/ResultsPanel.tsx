import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ScanStatus } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import DiscoveredHosts from "@/components/DiscoveredHosts";
import RawOutput from "@/components/RawOutput";
import { Skeleton } from "@/components/ui/skeleton";

interface ResultsPanelProps {
  scanId: number | null;
  view: "idle" | "loading" | "results" | "error";
  onViewChange?: (view: "idle" | "loading" | "results" | "error") => void;
  onNewScan?: () => void;
}

export default function ResultsPanel({ 
  scanId, 
  view, 
  onViewChange,
  onNewScan 
}: ResultsPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("Initializing scan...");
  const [filterQuery, setFilterQuery] = useState("");
  
  // Query the scan details if we have a scanId
  const { 
    data: scan, 
    isLoading, 
    isError,
    refetch 
  } = useQuery({
    queryKey: scanId ? [`/api/scans/${scanId}`] : ['no-scan'],
    enabled: !!scanId,
    refetchInterval: view === "loading" ? 2000 : false // Poll when loading
  });
  
  // Query to get raw output
  const { data: scanWithOutput } = useQuery({
    queryKey: scanId ? [`/api/scans/${scanId}`, { includeOutput: true }] : ['no-scan-output'],
    enabled: !!scanId && view === "results",
  });
  
  // Cancel scan mutation
  const { mutate: cancelScan, isPending: isCancelling } = useMutation({
    mutationFn: async () => {
      if (!scanId) return null;
      const response = await apiRequest("POST", `/api/scans/${scanId}/cancel`, {});
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Scan Cancelled",
        description: "The scan has been cancelled",
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to cancel scan",
        variant: "destructive",
      });
    },
  });
  
  // Calculate progress for running scans
  useEffect(() => {
    if (scan?.status === ScanStatus.RUNNING) {
      // Simulate progress based on time elapsed
      const startTime = scan.startTime ? new Date(scan.startTime).getTime() : Date.now();
      const elapsed = Date.now() - startTime;
      
      // Assume typical scan takes about 2 minutes for full progress
      const estimatedTotalTime = 120000; // 2 minutes in ms
      const calculatedProgress = Math.min((elapsed / estimatedTotalTime) * 100, 99);
      
      setProgress(calculatedProgress);
      
      // Update status text based on progress
      if (calculatedProgress < 20) {
        setStatusText("Initializing scan and resolving target...");
      } else if (calculatedProgress < 50) {
        setStatusText("Scanning ports and detecting services...");
      } else if (calculatedProgress < 80) {
        setStatusText("Running version detection and OS fingerprinting...");
      } else {
        setStatusText("Finalizing scan results...");
      }
    }
  }, [scan]);
  
  // Update the view based on scan status
  useEffect(() => {
    if (!scan || !onViewChange) return;
    
    if (scan.status === ScanStatus.RUNNING || scan.status === ScanStatus.PENDING) {
      onViewChange("loading");
    } else if (scan.status === ScanStatus.COMPLETED) {
      onViewChange("results");
    } else if (scan.status === ScanStatus.FAILED) {
      onViewChange("error");
    }
  }, [scan, onViewChange]);
  
  // Handle download results
  const handleDownloadResults = () => {
    if (!scan) return;
    
    const output = scanWithOutput?.output || "";
    const blob = new Blob([output], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nmap_scan_${scan.id}_${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  // Format duration in human-readable format
  const formatDuration = (seconds?: number) => {
    if (!seconds) return "N/A";
    
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    
    if (mins === 0) {
      return `${secs} seconds`;
    } else {
      return `${mins} minute${mins > 1 ? 's' : ''} ${secs} second${secs !== 1 ? 's' : ''}`;
    }
  };
  
  // Render different views based on the current state
  
  // Idle state - no scan selected
  if (view === "idle") {
    return (
      <div className="bg-white rounded-lg shadow-md p-5 h-full flex flex-col justify-center items-center text-center py-16">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-16 h-16 text-gray-300 mb-4"
        >
          <path d="M5 12.55a11 11 0 0 1 14.08 0" />
          <path d="M1.42 9a16 16 0 0 1 21.16 0" />
          <path d="M8.53 16.11a6 6 0 0 1 6.95 0" />
          <circle cx="12" cy="20" r="1" />
        </svg>
        <h2 className="text-xl font-medium text-gray-700 mb-2">No Scan Results</h2>
        <p className="text-gray-500 max-w-md">Configure your scan parameters and click "Start Scan" to begin network discovery</p>
      </div>
    );
  }
  
  // Loading state - scan in progress
  if (view === "loading") {
    return (
      <div className="bg-white rounded-lg shadow-md p-5">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium text-primary flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-5 h-5 mr-2 animate-spin"
            >
              <path d="M21 12a9 9 0 1 1-6.219-8.56" />
            </svg>
            Scan in Progress
          </h2>
          <Button 
            variant="ghost" 
            className="text-gray-500 hover:text-red-500"
            onClick={() => cancelScan()}
            disabled={isCancelling}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-4 h-4 mr-1"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="m15 9-6 6" />
              <path d="m9 9 6 6" />
            </svg>
            Cancel
          </Button>
        </div>
        
        <div className="border border-gray-200 rounded-md p-4 mb-4">
          <div className="flex justify-between mb-2">
            <div>
              <span className="text-sm font-medium">Target:</span>
              <span className="text-sm ml-2">{scan?.target || <Skeleton className="inline-block h-4 w-20" />}</span>
            </div>
            <div>
              <span className="text-sm font-medium">Type:</span>
              <span className="text-sm ml-2">{scan?.type || <Skeleton className="inline-block h-4 w-16" />}</span>
            </div>
          </div>
          <div className="mb-3">
            <div className="flex justify-between items-center text-sm mb-1">
              <span>Progress</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-500 ease-in-out" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>
          <div className="text-xs text-gray-500">
            {statusText}
          </div>
        </div>
        
        <div className="mb-4">
          <h3 className="text-sm font-medium text-gray-700 mb-2">Live Output</h3>
          <div className="bg-gray-900 text-gray-100 rounded-md p-3 font-mono text-xs h-64 overflow-y-auto">
            {isLoading ? (
              <div className="animate-pulse">Loading scan data...</div>
            ) : (
              <pre>{scan?.output || "Waiting for scan output..."}</pre>
            )}
          </div>
        </div>
        
        <div>
          <div className="flex items-center text-sm text-gray-500">
            <div className="animate-pulse mr-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-4 h-4 text-primary"
              >
                <path d="M21 12a9 9 0 1 1-6.219-8.56" />
              </svg>
            </div>
            <span>
              Estimated time remaining: ~{Math.max(2 - Math.round(progress / 50), 0)} minute{Math.max(2 - Math.round(progress / 50), 0) !== 1 && 's'}
            </span>
          </div>
        </div>
      </div>
    );
  }
  
  // Results state - scan completed
  if (view === "results" && scan) {
    return (
      <div className="bg-white rounded-lg shadow-md p-5">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium text-primary flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-5 h-5 mr-2"
            >
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <path d="m9 11 3 3L22 4" />
            </svg>
            Scan Results
          </h2>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleDownloadResults}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-4 h-4 mr-1"
              >
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="7 10 12 15 17 10" />
                <line x1="12" x2="12" y1="15" y2="3" />
              </svg>
              Export
            </Button>
            <Button 
              onClick={onNewScan}
              size="sm"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-4 h-4 mr-1"
              >
                <path d="M5 12h14" />
                <path d="M12 5v14" />
              </svg>
              New Scan
            </Button>
          </div>
        </div>
        
        <div className="border border-gray-200 rounded-md p-4 mb-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
            <div>
              <span className="text-sm font-medium block">Target:</span>
              <span className="text-sm">{scan.target}</span>
            </div>
            <div>
              <span className="text-sm font-medium block">Duration:</span>
              <span className="text-sm">{formatDuration(scan.duration)}</span>
            </div>
            <div>
              <span className="text-sm font-medium block">Hosts Discovered:</span>
              <span className="text-sm">
                {scan.hostsUp || 0} {scan.hostsTotal ? `out of ${scan.hostsTotal}` : ''}
              </span>
            </div>
          </div>
          <div className="flex justify-between items-center text-xs px-1">
            <span className="text-gray-500">
              {scan.endTime && `Completed on ${new Date(scan.endTime).toLocaleString()}`}
            </span>
            <span className="px-2 py-0.5 bg-green-100 text-green-800 rounded-full">
              Completed Successfully
            </span>
          </div>
        </div>
        
        <DiscoveredHosts 
          hosts={scan.hosts || []} 
          filterQuery={filterQuery}
          onFilterChange={setFilterQuery}
        />
        
        <RawOutput output={scanWithOutput?.output || ""} />
      </div>
    );
  }
  
  // Error state - scan failed
  if (view === "error" && scan) {
    return (
      <div className="bg-white rounded-lg shadow-md p-5">
        <div className="flex items-center mb-4 text-red-500">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-5 h-5 mr-2"
          >
            <circle cx="12" cy="12" r="10" />
            <line x1="12" x2="12" y1="8" y2="12" />
            <line x1="12" x2="12.01" y1="16" y2="16" />
          </svg>
          <h2 className="text-lg font-medium">Scan Failed</h2>
        </div>
        
        <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-4">
          <h3 className="text-md font-medium text-red-800 mb-2">Error Details</h3>
          <div className="text-sm text-red-700 whitespace-pre-wrap">
            {scan.error || "Unknown error occurred during the scan"}
          </div>
        </div>
        
        <div className="bg-gray-100 rounded-md p-4 mb-4">
          <h3 className="text-sm font-medium text-gray-700 mb-2">Scan Parameters</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Target:</span>
              <span className="ml-2">{scan.target}</span>
            </div>
            <div>
              <span className="font-medium">Scan Type:</span>
              <span className="ml-2">{scan.type}</span>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Troubleshooting</h3>
          <ul className="list-disc list-inside text-sm space-y-1 text-gray-700">
            <li>Make sure you have sufficient permissions to run Nmap</li>
            <li>Verify the target IP/hostname is valid and reachable</li>
            <li>Check if firewall rules are blocking the scan</li>
            <li>Ensure Nmap is properly installed on the server</li>
          </ul>
          
          <div className="mt-4 flex space-x-3">
            <Button onClick={() => refetch()}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-4 h-4 mr-2"
              >
                <path d="M21 2v6h-6" />
                <path d="M3 12a9 9 0 0 1 15-6.7L21 8" />
                <path d="M3 22v-6h6" />
                <path d="M21 12a9 9 0 0 1-15 6.7L3 16" />
              </svg>
              Retry Scan
            </Button>
            <Button variant="outline" onClick={onNewScan}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-4 h-4 mr-2"
              >
                <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
              </svg>
              Modify Parameters
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  // Loading state (when data is being fetched)
  return (
    <div className="bg-white rounded-lg shadow-md p-5">
      <Skeleton className="h-8 w-64 mb-4" />
      <div className="border border-gray-200 rounded-md p-4 mb-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      </div>
      <Skeleton className="h-64 w-full" />
    </div>
  );
}
