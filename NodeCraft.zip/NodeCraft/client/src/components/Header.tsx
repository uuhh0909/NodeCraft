import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";

export default function Header() {
  const [location] = useLocation();
  const { data: healthData, isLoading } = useQuery({ 
    queryKey: ['/api/health'],
    refetchInterval: 60000 // Check every minute
  });
  
  const serverStatus = isLoading 
    ? "checking" 
    : healthData?.status === "ok" 
      ? "online" 
      : "offline";
  
  const nmapStatus = isLoading
    ? "checking"
    : healthData?.nmap === "installed"
      ? "installed"
      : "not installed";
  
  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-6 h-6"
          >
            <path d="M5 12.55a11 11 0 0 1 14.08 0" />
            <path d="M1.42 9a16 16 0 0 1 21.16 0" />
            <path d="M8.53 16.11a6 6 0 0 1 6.95 0" />
            <circle cx="12" cy="20" r="1" />
          </svg>
          <h1 className="text-xl font-medium">Ethical Hacking Toolkit</h1>
        </div>
        
        <nav className="hidden md:flex space-x-4">
          <Link href="/">
            <div className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${location === '/' ? 'bg-white bg-opacity-20' : 'hover:bg-white hover:bg-opacity-10'}`}>
              <span className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="11" cy="11" r="8" />
                  <path d="m21 21-4.3-4.3" />
                </svg>
                Scanner
              </span>
            </div>
          </Link>
          
          <Link href="/exploit-lab">
            <div className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${location === '/exploit-lab' ? 'bg-white bg-opacity-20' : 'hover:bg-white hover:bg-opacity-10'}`}>
              <span className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m8 13 2 2L22 4" />
                  <path d="M18 22H4a2 2 0 0 1-2-2V6" />
                </svg>
                Exploit Lab
              </span>
            </div>
          </Link>
          
          <Link href="/console">
            <div className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${location === '/console' ? 'bg-white bg-opacity-20' : 'hover:bg-white hover:bg-opacity-10'}`}>
              <span className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="9 11 12 14 22 4" />
                  <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
                </svg>
                Console
              </span>
            </div>
          </Link>
        </nav>
        
        {/* Mobile menu - displayed on smaller screens */}
        <div className="md:hidden">
          <div className="fixed bottom-0 left-0 right-0 bg-primary p-2 flex justify-around items-center border-t border-gray-700">
            <Link href="/">
              <div className={`p-2 rounded-md flex flex-col items-center ${location === '/' ? 'bg-white bg-opacity-20' : ''}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="11" cy="11" r="8" />
                  <path d="m21 21-4.3-4.3" />
                </svg>
                <span className="text-xs mt-1">Scanner</span>
              </div>
            </Link>
            
            <Link href="/exploit-lab">
              <div className={`p-2 rounded-md flex flex-col items-center ${location === '/exploit-lab' ? 'bg-white bg-opacity-20' : ''}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m8 13 2 2L22 4" />
                  <path d="M18 22H4a2 2 0 0 1-2-2V6" />
                </svg>
                <span className="text-xs mt-1">Exploit Lab</span>
              </div>
            </Link>
            
            <Link href="/console">
              <div className={`p-2 rounded-md flex flex-col items-center ${location === '/console' ? 'bg-white bg-opacity-20' : ''}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="9 11 12 14 22 4" />
                  <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
                </svg>
                <span className="text-xs mt-1">Console</span>
              </div>
            </Link>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <span className="flex items-center text-sm">
            <span 
              className={`inline-block w-2 h-2 rounded-full mr-2 ${
                serverStatus === "online" ? "bg-green-500" : 
                serverStatus === "checking" ? "bg-yellow-500" : "bg-red-500"
              }`}
            ></span>
            {serverStatus === "online" ? "Server Online" : 
             serverStatus === "checking" ? "Checking Status..." : "Server Offline"}
          </span>
          
          {nmapStatus !== "installed" && (
            <span className="text-xs bg-red-500 px-2 py-1 rounded-full">
              {nmapStatus === "checking" ? "Checking Nmap..." : "Nmap Not Installed"}
            </span>
          )}
        </div>
      </div>
    </header>
  );
}
