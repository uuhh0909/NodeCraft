import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface RawOutputProps {
  output: string;
}

export default function RawOutput({ output }: RawOutputProps) {
  const { toast } = useToast();
  const [isCollapsed, setIsCollapsed] = useState(true);
  
  // Toggle view
  const toggleView = () => {
    setIsCollapsed(!isCollapsed);
  };
  
  // Copy output to clipboard
  const copyOutput = () => {
    navigator.clipboard.writeText(output).then(
      () => {
        toast({
          title: "Copied",
          description: "Raw output copied to clipboard",
        });
      },
      (err) => {
        toast({
          title: "Copy Failed",
          description: `Could not copy text: ${err}`,
          variant: "destructive",
        });
      }
    );
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-md font-medium text-gray-800">Raw Nmap Output</h3>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={toggleView}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-4 h-4 mr-1"
            >
              <polyline points="15 3 21 3 21 9" />
              <polyline points="9 21 3 21 3 15" />
              <line x1="21" x2="14" y1="3" y2="10" />
              <line x1="3" x2="10" y1="21" y2="14" />
            </svg>
            {isCollapsed ? "Expand" : "Collapse"}
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={copyOutput}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-4 h-4 mr-1"
            >
              <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
              <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
            </svg>
            Copy
          </Button>
        </div>
      </div>
      
      <div 
        className={`bg-gray-900 text-gray-100 rounded-md p-3 font-mono text-xs overflow-y-auto transition-all duration-300 ease-in-out ${
          isCollapsed ? 'max-h-64' : 'max-h-[500px]'
        }`}
      >
        {output ? (
          <pre>{output}</pre>
        ) : (
          <div className="text-gray-400 italic">No raw output available</div>
        )}
      </div>
    </div>
  );
}
