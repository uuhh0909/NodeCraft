import { useQuery, useQueryClient } from "@tanstack/react-query";
import { formatRelative } from "date-fns";
import { ScanStatus } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface ScanHistoryProps {
  onSelectScan: (scanId: number) => void;
}

export default function ScanHistory({ onSelectScan }: ScanHistoryProps) {
  const queryClient = useQueryClient();
  
  // Query to get recent scans
  const { data: recentScans, isLoading } = useQuery({ 
    queryKey: ['/api/scans'],
    refetchInterval: 5000 // Refresh every 5 seconds to get updates
  });
  
  // Get friendly scan type names
  function getScanTypeName(type: string): string {
    switch(type) {
      case "quick": return "Quick Scan";
      case "full": return "Full Scan";
      case "os": return "OS Detection";
      case "custom": return "Custom Scan";
      case "nfs_scan": return "NFS Scan";
      case "vuln_scan": return "Vulnerability Scan";
      default: return type;
    }
  }
  
  // Format the date relative to now
  function formatDate(dateString: string): string {
    try {
      return formatRelative(new Date(dateString), new Date());
    } catch (e) {
      return "Unknown date";
    }
  }
  
  // Handle scan selection
  function handleSelectScan(scanId: number) {
    // Prefetch the scan details
    queryClient.prefetchQuery({ queryKey: [`/api/scans/${scanId}`] });
    onSelectScan(scanId);
  }
  
  return (
    <div className="mt-8">
      <h3 className="text-md font-medium text-gray-800 mb-3 flex items-center">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-4 h-4 mr-2"
        >
          <path d="M12 8v4l3 3" />
          <circle cx="12" cy="12" r="10" />
        </svg>
        Recent Scans
      </h3>
      
      <div className="border rounded-md divide-y divide-gray-200 max-h-64 overflow-y-auto">
        {isLoading ? (
          // Loading skeleton
          Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="p-3 flex justify-between items-center">
              <div className="w-full">
                <Skeleton className="h-4 w-24 mb-2" />
                <Skeleton className="h-3 w-32" />
              </div>
            </div>
          ))
        ) : recentScans && recentScans.length > 0 ? (
          // Render scan history
          recentScans.map((scan: any) => (
            <div 
              key={scan.id}
              className="p-3 hover:bg-gray-50 cursor-pointer flex justify-between items-center text-sm"
              onClick={() => handleSelectScan(scan.id)}
            >
              <div>
                <div className="font-medium">{scan.target}</div>
                <div className="text-xs text-gray-500">
                  {getScanTypeName(scan.type)} • {scan.startTime ? formatDate(scan.startTime) : "Unknown time"}
                </div>
              </div>
              <div className="flex items-center">
                {scan.status === ScanStatus.RUNNING && (
                  <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse mr-2" />
                )}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-4 h-4 text-gray-500"
                >
                  <path d="m9 18 6-6-6-6" />
                </svg>
              </div>
            </div>
          ))
        ) : (
          // Empty state
          <div className="p-4 text-center text-sm text-gray-500">
            No recent scans found
          </div>
        )}
      </div>
    </div>
  );
}
