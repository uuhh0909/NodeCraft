import { useState } from "react";
import { Host, Port } from "@shared/schema";
import { Input } from "@/components/ui/input";

interface DiscoveredHostsProps {
  hosts: Host[];
  filterQuery: string;
  onFilterChange: (query: string) => void;
}

export default function DiscoveredHosts({ 
  hosts, 
  filterQuery, 
  onFilterChange 
}: DiscoveredHostsProps) {
  const [expandedHosts, setExpandedHosts] = useState<Record<string, boolean>>({});
  
  // Toggle host details
  const toggleHostDetails = (hostIp: string) => {
    setExpandedHosts(prev => ({
      ...prev,
      [hostIp]: !prev[hostIp]
    }));
  };
  
  // Filter hosts based on search query
  const filteredHosts = hosts.filter(host => {
    if (!filterQuery) return true;
    
    const lowerQuery = filterQuery.toLowerCase();
    
    return (
      host.ip.toLowerCase().includes(lowerQuery) ||
      (host.hostname && host.hostname.toLowerCase().includes(lowerQuery)) ||
      (host.os && host.os.toLowerCase().includes(lowerQuery)) ||
      (host.vendor && host.vendor.toLowerCase().includes(lowerQuery)) ||
      (host.ports && host.ports.some(port => 
        port.port.toString().includes(lowerQuery) ||
        port.service.toLowerCase().includes(lowerQuery) ||
        (port.version && port.version.toLowerCase().includes(lowerQuery))
      ))
    );
  });
  
  // Determine host type icon
  const getHostIcon = (host: Host) => {
    // Try to determine device type based on open ports and OS info
    if (host.os?.toLowerCase().includes("router") || 
        host.ports?.some(p => p.port === 53) || 
        host.ports?.some(p => p.port === 161)) {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 mr-2 text-green-500"
        >
          <rect x="5" y="2" width="14" height="20" rx="2" />
          <path d="M8 6h.01" />
          <path d="M8 10h.01" />
          <path d="M8 14h.01" />
          <path d="M8 18h.01" />
          <path d="M16 6h.01" />
          <path d="M16 10h.01" />
          <path d="M16 14h.01" />
          <path d="M16 18h.01" />
        </svg>
      );
    } else if (host.os?.toLowerCase().includes("windows")) {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 mr-2 text-blue-500"
        >
          <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
          <line x1="8" x2="16" y1="21" y2="21" />
          <line x1="12" x2="12" y1="17" y2="21" />
        </svg>
      );
    } else if (host.os?.toLowerCase().includes("linux") || host.os?.toLowerCase().includes("unix")) {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 mr-2 text-yellow-500"
        >
          <rect x="4" y="4" width="16" height="16" rx="2" ry="2" />
          <rect x="9" y="9" width="6" height="6" />
          <line x1="9" x2="15" y1="2" y2="2" />
          <line x1="2" x2="2" y1="9" y2="15" />
          <line x1="22" x2="22" y1="9" y2="15" />
          <line x1="9" x2="15" y1="22" y2="22" />
        </svg>
      );
    } else {
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-5 h-5 mr-2 text-green-500"
        >
          <rect width="20" height="16" x="2" y="4" rx="2" />
          <path d="M6 8h.01" />
          <path d="M10 8h.01" />
          <path d="M14 8h.01" />
          <path d="M18 8h.01" />
          <path d="M8 12h.01" />
          <path d="M12 12h.01" />
          <path d="M16 12h.01" />
          <path d="M7 16h10" />
        </svg>
      );
    }
  };
  
  // Get a descriptive label for the host
  const getHostDescription = (host: Host) => {
    const portCount = host.ports?.length || 0;
    let deviceType = "Unknown";
    
    if (host.os?.toLowerCase().includes("router")) {
      deviceType = "Router";
    } else if (host.os?.toLowerCase().includes("windows")) {
      deviceType = "Windows Device";
    } else if (host.os?.toLowerCase().includes("linux")) {
      deviceType = "Linux Device";
    } else if (host.os?.toLowerCase().includes("mac") || host.os?.toLowerCase().includes("apple")) {
      deviceType = "Apple Device";
    } else if (host.ports?.some(p => p.port === 80 || p.port === 443) && 
              (host.ports?.some(p => p.service.includes("http")))) {
      deviceType = "Web Server";
    }
    
    return `${portCount} open port${portCount !== 1 ? 's' : ''} • ${deviceType}`;
  };
  
  return (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-md font-medium text-gray-800">Discovered Hosts</h3>
        <div className="relative">
          <Input
            type="text"
            placeholder="Filter results..."
            className="text-sm pl-8 pr-3 py-1 h-8"
            value={filterQuery}
            onChange={(e) => onFilterChange(e.target.value)}
          />
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-4 h-4 absolute left-2 top-2 text-gray-400"
          >
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.3-4.3" />
          </svg>
        </div>
      </div>
      
      {filteredHosts.length === 0 ? (
        <div className="text-center p-6 bg-gray-50 rounded-md border border-gray-200">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-8 h-8 mx-auto text-gray-400 mb-2"
          >
            <circle cx="12" cy="12" r="10" />
            <line x1="8" x2="16" y1="12" y2="12" />
          </svg>
          <h3 className="text-gray-500 font-medium">No hosts found</h3>
          <p className="text-sm text-gray-400 mt-1">
            {filterQuery ? "Try adjusting your filter criteria" : "No hosts were discovered in this scan"}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredHosts.map((host) => (
            <div key={host.ip} className="border border-gray-200 rounded-md overflow-hidden">
              <div 
                className="flex justify-between items-center p-3 bg-gray-50 cursor-pointer" 
                onClick={() => toggleHostDetails(host.ip)}
              >
                <div className="flex items-center">
                  {getHostIcon(host)}
                  <div>
                    <div className="font-medium">{host.ip} {host.hostname && `(${host.hostname})`}</div>
                    <div className="text-xs text-gray-500">{getHostDescription(host)}</div>
                  </div>
                </div>
                <div className="flex items-center">
                  {host.mac && (
                    <span className="text-xs px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full mr-2">
                      {host.vendor || "Unknown Vendor"}
                    </span>
                  )}
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className={`w-4 h-4 text-gray-400 transition-transform ${expandedHosts[host.ip] ? 'rotate-180' : ''}`}
                  >
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </div>
              </div>
              
              {expandedHosts[host.ip] && (
                <div className="p-3 bg-white">
                  {host.ports && host.ports.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="min-w-full text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Port</th>
                            <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                            <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">State</th>
                            <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Version</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {host.ports.map((port) => (
                            <tr key={`${port.port}-${port.protocol}`}>
                              <td className="px-3 py-2 whitespace-nowrap">{port.port}/{port.protocol}</td>
                              <td className="px-3 py-2 whitespace-nowrap">{port.service}</td>
                              <td className="px-3 py-2 whitespace-nowrap">
                                <span className={`px-2 py-0.5 rounded-full text-xs ${
                                  port.state === 'open' ? 'bg-green-100 text-green-800' : 
                                  port.state === 'closed' ? 'bg-red-100 text-red-800' : 
                                  'bg-yellow-100 text-yellow-800'
                                }`}>
                                  {port.state}
                                </span>
                              </td>
                              <td className="px-3 py-2 whitespace-nowrap">{port.version || "—"}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 italic">No open ports detected</p>
                  )}
                  
                  <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    {host.os && (
                      <div className="border border-gray-200 rounded p-2">
                        <div className="font-medium mb-1">OS Detection</div>
                        <div>{host.os} {host.osConfidence !== undefined && `(${host.osConfidence}% confidence)`}</div>
                      </div>
                    )}
                    {host.mac && (
                      <div className="border border-gray-200 rounded p-2">
                        <div className="font-medium mb-1">MAC Address</div>
                        <div>{host.mac} {host.vendor && `(${host.vendor})`}</div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
