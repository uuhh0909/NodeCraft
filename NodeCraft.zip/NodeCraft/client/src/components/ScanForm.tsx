import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { scanRequestSchema, ScanType } from "@shared/schema";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ScanFormProps {
  onScanStart: (scanId: number) => void;
  nmapInstalled: boolean | undefined;
}

export default function ScanForm({ onScanStart, nmapInstalled }: ScanFormProps) {
  const { toast } = useToast();
  const [showCustomOptions, setShowCustomOptions] = useState(false);
  
  // Form definition with Zod schema
  const form = useForm<z.infer<typeof scanRequestSchema>>({
    resolver: zodResolver(scanRequestSchema),
    defaultValues: {
      target: "",
      type: ScanType.QUICK,
      options: {
        verbose: false,
        saveResult: false
      }
    }
  });
  
  // Watch the scan type to show/hide custom options
  const scanType = form.watch("type");
  
  useEffect(() => {
    setShowCustomOptions(scanType === ScanType.CUSTOM);
  }, [scanType]);
  
  // Create scan mutation
  const { mutate, isPending } = useMutation({
    mutationFn: async (data: z.infer<typeof scanRequestSchema>) => {
      const response = await apiRequest("POST", "/api/scans", data);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Scan Started",
        description: `Scan ID: ${data.id} has been initiated`,
      });
      onScanStart(data.id);
    },
    onError: (error) => {
      toast({
        title: "Scan Failed",
        description: error.message || "Failed to start scan",
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  function onSubmit(data: z.infer<typeof scanRequestSchema>) {
    if (!nmapInstalled) {
      toast({
        title: "Nmap Not Installed",
        description: "Nmap is not installed or not accessible by the server",
        variant: "destructive",
      });
      return;
    }
    
    mutate(data);
  }
  
  // Fill local network for target field
  function fillLocalNetwork() {
    form.setValue("target", "192.168.1.0/24");
  }
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="target"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Target IP / Hostname</FormLabel>
              <div className="flex">
                <FormControl>
                  <Input 
                    placeholder="e.g., 192.168.1.1, example.com" 
                    {...field} 
                    className="rounded-r-none"
                  />
                </FormControl>
                <Button 
                  type="button" 
                  variant="outline"
                  className="rounded-l-none"
                  onClick={fillLocalNetwork}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="w-4 h-4"
                  >
                    <path d="M9 9V6a3 3 0 0 1 3-3h.75C14.43 3 16 4.57 16 6.25c0 .17-.02.34-.05.5" />
                    <path d="M4 22h14" />
                    <path d="M14.5 9H6a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-1.5" />
                    <path d="M12 19v3" />
                    <path d="M8 22V19" />
                    <path d="M16 22V19" />
                  </svg>
                </Button>
              </div>
              <p className="text-xs text-gray-500">Enter a single IP, CIDR range, or hostname</p>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="type"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Scan Type</FormLabel>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="grid grid-cols-3 gap-3"
                >
                  <FormItem className="relative">
                    <FormControl>
                      <RadioGroupItem 
                        value={ScanType.QUICK} 
                        id="scanType-quick"
                        className="sr-only peer"
                      />
                    </FormControl>
                    <label
                      htmlFor="scanType-quick"
                      className="flex p-3 bg-white border border-gray-300 rounded-md cursor-pointer peer-checked:border-primary peer-checked:bg-primary-light/10 hover:bg-gray-50"
                    >
                      <div className="w-full text-sm font-medium">Quick Scan</div>
                    </label>
                  </FormItem>
                  
                  <FormItem className="relative">
                    <FormControl>
                      <RadioGroupItem 
                        value={ScanType.FULL} 
                        id="scanType-full"
                        className="sr-only peer"
                      />
                    </FormControl>
                    <label
                      htmlFor="scanType-full"
                      className="flex p-3 bg-white border border-gray-300 rounded-md cursor-pointer peer-checked:border-primary peer-checked:bg-primary-light/10 hover:bg-gray-50"
                    >
                      <div className="w-full text-sm font-medium">Full Scan</div>
                    </label>
                  </FormItem>
                  
                  <FormItem className="relative">
                    <FormControl>
                      <RadioGroupItem 
                        value={ScanType.OS} 
                        id="scanType-os"
                        className="sr-only peer"
                      />
                    </FormControl>
                    <label
                      htmlFor="scanType-os"
                      className="flex p-3 bg-white border border-gray-300 rounded-md cursor-pointer peer-checked:border-primary peer-checked:bg-primary-light/10 hover:bg-gray-50"
                    >
                      <div className="w-full text-sm font-medium">OS Detection</div>
                    </label>
                  </FormItem>
                  
                  <FormItem className="relative">
                    <FormControl>
                      <RadioGroupItem 
                        value={ScanType.NFS_SCAN} 
                        id="scanType-nfs"
                        className="sr-only peer"
                      />
                    </FormControl>
                    <label
                      htmlFor="scanType-nfs"
                      className="flex p-3 bg-white border border-gray-300 rounded-md cursor-pointer peer-checked:border-primary peer-checked:bg-primary-light/10 hover:bg-gray-50"
                    >
                      <div className="w-full text-sm font-medium flex items-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="w-4 h-4 mr-1 text-yellow-600"
                        >
                          <path d="M2 9V5c0-1.1.9-2 2-2h16a2 2 0 0 1 2 2v4" />
                          <path d="M2 13v6c0 1.1.9 2 2 2h16a2 2 0 0 0 2-2v-6" />
                          <path d="M2 9h20" />
                          <path d="M2 13h20" />
                        </svg>
                        NFS Scan
                      </div>
                    </label>
                  </FormItem>
                  
                  <FormItem className="relative">
                    <FormControl>
                      <RadioGroupItem 
                        value={ScanType.VULN_SCAN} 
                        id="scanType-vuln"
                        className="sr-only peer"
                      />
                    </FormControl>
                    <label
                      htmlFor="scanType-vuln"
                      className="flex p-3 bg-white border border-gray-300 rounded-md cursor-pointer peer-checked:border-primary peer-checked:bg-primary-light/10 hover:bg-gray-50"
                    >
                      <div className="w-full text-sm font-medium flex items-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="w-4 h-4 mr-1 text-red-600"
                        >
                          <path d="m8 13 2 2L22 4" />
                          <path d="M18 22H4a2 2 0 0 1-2-2V6" />
                        </svg>
                        Vuln Scan
                      </div>
                    </label>
                  </FormItem>
                  
                  <FormItem className="relative">
                    <FormControl>
                      <RadioGroupItem 
                        value={ScanType.CUSTOM} 
                        id="scanType-custom"
                        className="sr-only peer"
                      />
                    </FormControl>
                    <label
                      htmlFor="scanType-custom"
                      className="flex p-3 bg-white border border-gray-300 rounded-md cursor-pointer peer-checked:border-primary peer-checked:bg-primary-light/10 hover:bg-gray-50"
                    >
                      <div className="w-full text-sm font-medium">Custom</div>
                    </label>
                  </FormItem>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {showCustomOptions && (
          <FormField
            control={form.control}
            name="customFlags"
            render={({ field }) => (
              <FormItem>
                <div className="p-3 border border-gray-300 rounded-md bg-gray-50">
                  <FormLabel>Custom Nmap Flags</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="-sS -p 1-1000 -T4"
                      {...field}
                      className="font-mono text-sm"
                    />
                  </FormControl>
                  <p className="mt-1 text-xs text-gray-500">Enter custom Nmap command flags</p>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
        
        <div>
          <FormLabel>Advanced Options</FormLabel>
          <div className="space-y-2">
            <FormField
              control={form.control}
              name="options.verbose"
              render={({ field }) => (
                <FormItem className="flex items-center space-x-2">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <label
                    htmlFor="verbose"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Verbose Output
                  </label>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="options.saveResult"
              render={({ field }) => (
                <FormItem className="flex items-center space-x-2">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <label
                    htmlFor="saveResult"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Save Results
                  </label>
                </FormItem>
              )}
            />
          </div>
        </div>
        
        <div className="pt-2">
          <Button 
            type="submit" 
            className="w-full"
            disabled={isPending || !nmapInstalled}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-4 h-4 mr-2"
            >
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
            {isPending ? "Starting Scan..." : "Start Scan"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
